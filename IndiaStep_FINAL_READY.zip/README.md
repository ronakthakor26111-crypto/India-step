# India Step – Android Pedometer

Mobile-friendly Android project for GitHub Actions.

## Build APK from phone
1. Create a GitHub repository.
2. Upload the **contents** of this ZIP (not the ZIP itself).
3. Open **Actions** → **Build India Step APK** → **Run workflow**.
4. When finished, open the run → **Artifacts** → **IndiaStep-debug-apk**.

Features in this build:
- Android step counter sensor
- Background foreground-service tracking
- Daily goal
- Distance and calorie estimates
- Animated step number
- Hindi, Gujarati, Marathi, Bengali, Tamil, Telugu, Kannada, Malayalam, Punjabi, Odia, Assamese, Urdu and English resources
- Offline local storage
- Dark-mode compatible Android theme
