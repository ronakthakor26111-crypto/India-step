package com.indiastap.indiaStep

import android.app.*
import android.content.*
import android.hardware.*
import android.os.*
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.*

class StepService : Service(), SensorEventListener {
    private lateinit var sm: SensorManager
    private val prefs by lazy { getSharedPreferences("india_step", MODE_PRIVATE) }
    private val day: String get() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private var baseline = -1f

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel("steps", "India Step", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val n = NotificationCompat.Builder(this, "steps")
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.tracking_active))
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build()
        startForeground(101, n)

        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)?.let {
            baseline = prefs.getFloat("baseline", -1f)
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        val raw = e.values[0]
        var steps = prefs.getInt("steps", 0)
        if (prefs.getString("date", "") != day) {
            steps = 0
            baseline = raw
        }
        if (baseline < 0f) baseline = raw - steps
        if (raw < baseline) baseline = raw - steps
        steps = maxOf(0, (raw - baseline).toInt())
        prefs.edit().putString("date", day).putInt("steps", steps).putFloat("baseline", baseline).apply()
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    override fun onBind(i: Intent?) = null
    override fun onDestroy() {
        sm.unregisterListener(this)
        super.onDestroy()
    }
}
