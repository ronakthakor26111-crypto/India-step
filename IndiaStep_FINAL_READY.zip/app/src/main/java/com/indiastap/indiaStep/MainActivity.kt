package com.indiastap.indiaStep

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.hardware.*
import android.os.*
import android.text.InputType
import android.view.animation.DecelerateInterpolator
import android.animation.ValueAnimator
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity(), SensorEventListener {
    private lateinit var sm: SensorManager
    private var sensor: Sensor? = null
    private lateinit var stepsV: TextView
    private lateinit var distanceV: TextView
    private lateinit var caloriesV: TextView
    private lateinit var goalV: TextView
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("india_step", MODE_PRIVATE) }
    private var baseline = -1f
    private var steps = 0
    private var goal = 10000
    private val day: String get() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        stepsV = findViewById(R.id.steps)
        distanceV = findViewById(R.id.distance)
        caloriesV = findViewById(R.id.calories)
        goalV = findViewById(R.id.goal)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)

        goal = prefs.getInt("goal", 10000)
        if (prefs.getString("date", "") != day) {
            prefs.edit().putString("date", day).putInt("steps", 0).putFloat("baseline", -1f).apply()
        }
        steps = prefs.getInt("steps", 0)
        baseline = prefs.getFloat("baseline", -1f)
        render(false)

        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        sensor = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        if (sensor == null) status.text = getString(R.string.sensor_missing)

        findViewById<Button>(R.id.start).setOnClickListener {
            if (Build.VERSION.SDK_INT >= 29 && checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), 42)
            } else {
                startTracker()
            }
        }
        findViewById<Button>(R.id.stop).setOnClickListener {
            stopService(Intent(this, StepService::class.java))
            status.text = getString(R.string.stop)
        }
        findViewById<Button>(R.id.setGoal).setOnClickListener { showGoalDialog() }
    }

    private fun startTracker() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 43)
        }
        startForegroundService(Intent(this, StepService::class.java))
        status.text = getString(R.string.start)
    }

    private fun showGoalDialog() {
        val e = EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setText(goal.toString())
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.set_goal))
            .setView(e)
            .setPositiveButton(getString(R.string.save)) { _, _ ->
                e.text.toString().toIntOrNull()?.let {
                    goal = it.coerceIn(100, 100000)
                    prefs.edit().putInt("goal", goal).apply()
                    render(true)
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 42 && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) startTracker()
    }

    override fun onResume() {
        super.onResume()
        sensor?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        steps = prefs.getInt("steps", steps)
        render(false)
    }

    override fun onPause() {
        sm.unregisterListener(this)
        super.onPause()
    }

    override fun onSensorChanged(e: SensorEvent) {
        val raw = e.values[0]
        if (prefs.getString("date", "") != day) {
            steps = 0
            baseline = raw
            prefs.edit().putString("date", day).putInt("steps", 0).putFloat("baseline", raw).apply()
        }
        if (baseline < 0f) baseline = prefs.getFloat("baseline", raw - steps)
        if (raw < baseline) baseline = raw - steps
        steps = maxOf(0, (raw - baseline).toInt())
        prefs.edit().putInt("steps", steps).putFloat("baseline", baseline).putString("date", day).apply()
        render(true)
        if (steps >= goal) status.text = getString(R.string.goal_done)
    }

    private fun render(anim: Boolean) {
        val old = stepsV.text.toString().replace(",", "").toIntOrNull() ?: 0
        if (anim) {
            ValueAnimator.ofInt(old, steps).apply {
                duration = 350
                interpolator = DecelerateInterpolator()
                addUpdateListener { stepsV.text = String.format(Locale.US, "%,d", it.animatedValue as Int) }
                start()
            }
        } else stepsV.text = String.format(Locale.US, "%,d", steps)
        distanceV.text = String.format(Locale.US, "%.2f km", steps * 0.00075)
        caloriesV.text = String.format(Locale.US, "%d kcal", (steps * 0.04).toInt())
        goalV.text = getString(R.string.goal_format, goal)
        progress.progress = (steps.toFloat() / goal * 100).coerceIn(0f, 100f).toInt()
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}
