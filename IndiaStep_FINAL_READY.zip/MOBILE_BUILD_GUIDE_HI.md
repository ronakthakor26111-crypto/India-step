# India Step – मोबाइल से APK बनाने की आसान विधि

### 1) ZIP डाउनलोड करें
इस ZIP को फोन में डाउनलोड करके **Extract** करें।

### 2) GitHub खोलें
https://github.com पर account में login करें और **New repository** से `IndiaStep` नाम की repository बनाएं।

### 3) Files upload करें
Repository में **Add file → Upload files** चुनें।
Extract किए हुए folder के **अंदर की सभी files/folders** upload करें। ZIP को सीधे upload न करें।

ध्यान दें: `.github` folder भी upload होना चाहिए। उसमें `workflows/build.yml` है।

### 4) APK build करें
Repository में **Actions** खोलें → **Build India Step APK** → **Run workflow**।

### 5) APK लें
Build सफल होने पर workflow खोलें → नीचे **Artifacts** में `IndiaStep-debug-apk` दबाएं और APK डाउनलोड करें।

यह project debug APK बनाता है। Play Store पर डालने के लिए बाद में signed AAB और Play Console setup करना होगा।
